package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class Company_account extends AppCompatActivity {
    TextView clogout;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_account);
        clogout=findViewById(R.id.clogout);
        clogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                startActivity(new Intent(Company_account.this, CompanyLoginActivity.class));
                finish();
            }
        });

    }
}