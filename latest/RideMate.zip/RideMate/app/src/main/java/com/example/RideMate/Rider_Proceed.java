package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Rider_Proceed extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_proceed);
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();

        check(currentuser);

    }

    private void check( String currentuser) {

        FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child("rideend").exists() || snapshot.child("accepted").exists() || snapshot.child("ridestarted").exists()){
                    check(currentuser);

                }
                else{
                    startActivity(new Intent(Rider_Proceed.this, RiderHomePage.class));
                    Toast.makeText(Rider_Proceed.this,"Ride Ended! Please View ride details in History",Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}