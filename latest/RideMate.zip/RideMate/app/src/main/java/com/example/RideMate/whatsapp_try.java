package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.textfield.TextInputEditText;
import com.karumi.dexter.Dexter;

public class whatsapp_try extends AppCompatActivity {
TextInputEditText txtmsg,txtnum;
ImageView contacts;
Button btnsms;
private static final int CONTACT_PICKER_REQUEST=202;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whatsapp_try);
        txtmsg=findViewById(R.id.txtmsg);
        txtnum=findViewById(R.id.txtnum);
        contacts=findViewById(R.id.contacts);
        btnsms=findViewById(R.id.btnsms);
        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btnsms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}