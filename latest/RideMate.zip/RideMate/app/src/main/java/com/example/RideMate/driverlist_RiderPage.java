package com.example.RideMate;
//
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
//
import java.util.ArrayList;
//
public class driverlist_RiderPage extends AppCompatActivity {
    //for showing driver name
    RecyclerView recview,recview2;
    ScrollView scroll,scroll2;
    myadapter adapter,adapter2;
    TextView companytext;
    Bitmap bitmap;
    String rcompany;
    ArrayList<String> cdriver;
    int len;
    //For spinner
    Spinner spinnerwith;
    boolean spinnerTouched = false;
    int currentItem=0;
    String cname2;
    DatabaseReference databaseReference;
    ValueEventListener listener;
    FirebaseAuth mAuth;
    Button cride1;
    ArrayAdapter<String> aadapter;
    ArrayList<String> spinnerDataList;
    static String cname1 ="Individual";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driverlist_rider_page);
        //Storing Current user's company name
        recview = findViewById(R.id.recview);
        recview2 = findViewById(R.id.recview2);
        scroll = findViewById(R.id.scroll);
        scroll2 = findViewById(R.id.scroll2);
        cride1 = findViewById(R.id.cride1);
        spinnerwith=(Spinner) findViewById(R.id.spinnerwith);


//        Toast.makeText(this, "company", Toast.LENGTH_SHORT).show();
        cride1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(driverlist_RiderPage.this,rider_current_ride.class));
            }
        });
//         FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
////                Toast.makeText(driverlist_RiderPage.this, snapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
//                Toast.makeText(driverlist_RiderPage.this, snapshot.toString(), Toast.LENGTH_SHORT).show();
//
//                rcompany=snapshot.child("company").getValue(String.class);
//                Toast.makeText(driverlist_RiderPage.this, "company111", Toast.LENGTH_SHORT).show();
//                Toast.makeText(driverlist_RiderPage.this, rcompany, Toast.LENGTH_SHORT).show();
////                recview.setLayoutManager(new LinearLayoutManager(driverlist_RiderPage.this));
////                FirebaseRecyclerOptions<rModel> options =
////                        new FirebaseRecyclerOptions.Builder<rModel>()
////                                .setQuery(FirebaseDatabase.getInstance().getReference().child("drivers"),rModel.class).build();
////                adapter = new myadapter(options,getApplicationContext());
////                recview.setAdapter(adapter);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//        rModel r = new rModel();
        String currentUser=FirebaseAuth.getInstance().getCurrentUser().getUid();
//        FirebaseDatabase.getInstance().getReference().child("riders").child(currentUser).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//               cname1=snapshot.child("company").getValue(String.class);
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
        final String company = getIntent().getStringExtra("company");


//useData();

//        Toast.makeText(driverlist_RiderPage.this,useData().get,Toast.LENGTH_SHORT).show();
        Toast.makeText(driverlist_RiderPage.this,company,Toast.LENGTH_SHORT).show();

//        cname1 = r.getName();
//
//
//                Toast.makeText(driverlist_RiderPage.this,companytext.getText().toString(),Toast.LENGTH_SHORT).show();



        //For Dropdown Spinner of Company and Individual
        spinnerwith = findViewById(R.id.spinnerwith);
        spinnerDataList = new ArrayList<>();
        aadapter = new ArrayAdapter<String>(driverlist_RiderPage.this, android.R.layout.simple_spinner_dropdown_item, spinnerDataList);
        spinnerwith.setAdapter(aadapter);
        retrivedata1(company);//for setting data in spinner





        spinnerwith.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    Toast.makeText(driverlist_RiderPage.this, spinnerwith.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
//                    cname1 = spinnerwith.getSelectedItem().toString();
                String selectedItem = parent.getItemAtPosition(position).toString();
                if (selectedItem.equals(company)) {
                    scroll.setVisibility(View.GONE);
                    recview.setVisibility(View.GONE);
                    scroll2.setVisibility(View.VISIBLE);
                    recview2.setVisibility(View.VISIBLE);
//                    Toast.makeText(driverlist_RiderPage.this, "company", Toast.LENGTH_LONG).show();

                } else if (selectedItem.equals("Individual")) {
//                    scroll2.setVisibility(View.VISIBLE);
                    recview2.setVisibility(View.GONE);
                    scroll2.setVisibility(View.GONE);
                    scroll.setVisibility(View.VISIBLE);
                    recview.setVisibility(View.VISIBLE);
//                    Toast.makeText(driverlist_RiderPage.this, "individual", Toast.LENGTH_LONG).show();

                }



            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
//        if(cname1.equals("Individual")){
            recview.setLayoutManager(new LinearLayoutManager(driverlist_RiderPage.this));
            FirebaseRecyclerOptions<rModel> options =
                    new FirebaseRecyclerOptions.Builder<rModel>()
                            .setQuery(FirebaseDatabase.getInstance().getReference().child("drivers"),rModel.class).build();
            adapter = new myadapter(options,getApplicationContext());
//        Toast.makeText(driverlist_RiderPage.this, "recview", Toast.LENGTH_LONG).show();
        recview.setAdapter(adapter);
//        }
//        else{
            recview2.setLayoutManager(new LinearLayoutManager(driverlist_RiderPage.this));
            FirebaseRecyclerOptions<rModel> options2 =
                    new FirebaseRecyclerOptions.Builder<rModel>()
                            .setQuery(FirebaseDatabase.getInstance().getReference().child("companyusers").child(company).child("drivers"),rModel.class).build();
            adapter2 = new myadapter(options2,getApplicationContext());
//        Toast.makeText(driverlist_RiderPage.this, "recview2", Toast.LENGTH_LONG).show();
        recview2.setAdapter(adapter2);
//        }




    }



    private void retrivedata1(String company) {
        listener = FirebaseDatabase.getInstance().getReference().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

//                FirebaseDatabase.getInstance().getReference().child("companynames").addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        for(DataSnapshot s : snapshot.getChildren()){
//                            Toast.makeText(driverlist_RiderPage.this,s.getValue().toString(),Toast.LENGTH_SHORT).show();
                            spinnerDataList.add(company);
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });
                spinnerDataList.add("Individual");
                aadapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    protected void onStart(){
        super.onStart();
        adapter.startListening();
        adapter2.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        adapter.stopListening();
        adapter2.stopListening();
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Intent i = new Intent(driverlist_RiderPage.this, RiderHomePage.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        finish();
    }

    }

