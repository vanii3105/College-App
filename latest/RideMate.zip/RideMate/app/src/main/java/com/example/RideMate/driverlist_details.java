package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class driverlist_details extends AppCompatActivity {

    private long pressed;
    DatabaseReference requestRef,friendRef;
    FirebaseAuth mAuth;
    FirebaseUser mUser;
    TextView name,source,dest;
    ImageView dimg;
    MaterialButton sendReq,declineReq;
    Button back;


    public static String CurrentState="nothing_happen";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driverlist_details);
        mAuth = FirebaseAuth.getInstance();
        mUser=mAuth.getCurrentUser();
        dimg=findViewById(R.id.dimg);
//        Toast.makeText(List_Details_Activity.this, "!!!!", Toast.LENGTH_LONG).show();
//        final String userID = FirebaseAuth.getInstance().getCurrentUser().getUid();
//        mUserRef = FirebaseDatabase.getInstance().getReference().child("users").child(userID);
        //back=findViewById(R.id.back);

        name = findViewById(R.id.dummyName);
        dimg = findViewById(R.id.dimg);
        source = findViewById(R.id.dummySource);
        dest = findViewById(R.id.dummydest);
        sendReq = findViewById(R.id.sendReq);
        declineReq = findViewById(R.id.cancelReq);


        name.setText(getIntent().getStringExtra("name"));
        source.setText(getIntent().getStringExtra("source"));
        dest.setText(getIntent().getStringExtra("destination"));
        final String purl = getIntent().getStringExtra("purl");

        Glide.with(driverlist_details.this).load(purl).into(dimg);

        // location.setText(getIntent().getStringExtra("location"));

        final String userID = getIntent().getStringExtra("userid");

        requestRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(userID).child("requests");
        friendRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(userID).child("accepted");

        FirebaseDatabase.getInstance().getReference().child("riders").child(mUser.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    sendReq.setText("Cancel Ride Request");
                    CurrentState="I_sent_pending";
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        friendRef.child(mUser.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    if(snapshot.child("status").getValue().toString().equals("accepted"))
                    {
                        sendReq.setVisibility(View.GONE);
                        declineReq.setVisibility(View.GONE);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//        Toast.makeText(List_Details_Activity.this, userid, Toast.LENGTH_LONG).show();
//        Toast.makeText(List_Details_Activity.this, "lllll", Toast.LENGTH_LONG).show();
//        HashMap h = new HashMap();
//        h.put("CurrentState","nothing_happen");
//        requestRef.child(mUser.getUid()).updateChildren(h);

        sendReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PerformAction(userID);
            }
        });

        declineReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

//        back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(driverlist_details.this, driverlist_RiderPage.class);
//                startActivity(i);
////                finish();
//            }
//        });
    }
//    public static String getCurrentState(){
//        return CurrentState;
//    }

    private void PerformAction(String userID) {
        if(CurrentState.equals("nothing_happen")){
            HashMap hashMap = new HashMap();
            hashMap.put("status","pending");

            requestRef.child(mUser.getUid()).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()){
                        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                        firebaseDatabase.getReference().child("riders").child(mUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                                String rname = snapshot.child("name").getValue(String.class);
                                String rsource = snapshot.child("source").getValue(String.class);
                                String rdestination = snapshot.child("destination").getValue(String.class);
                                String rid = snapshot.child("userid").getValue(String.class);
                                String rpurl = snapshot.child("purl").getValue(String.class);
                                HashMap<String,Object> m = new HashMap<String,Object>();
                                m.put("name",rname);
                                m.put("source",rsource);
                                m.put("destination",rdestination);
                                m.put("userid",rid);
                                m.put("purl",rpurl);
                                requestRef.child(mUser.getUid()).updateChildren(m);
                            }
                            @Override public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
//                        firebaseDatabase.getReference().child("riders").child(mUser.getUid()).child("location").addListenerForSingleValueEvent(new ValueEventListener() {@Override public void onDataChange(@NonNull DataSnapshot snapshot) {String rlocation = snapshot.getValue(String.class);HashMap<String,Object> m = new HashMap<String,Object>();m.put("location",rlocation);requestRef.child(mUser.getUid()).updateChildren(m);}@Override public void onCancelled(@NonNull DatabaseError error) {}});
//                        firebaseDatabase.getReference().child("riders").child(mUser.getUid()).child("userid").addListenerForSingleValueEvent(new ValueEventListener() {@Override public void onDataChange(@NonNull DataSnapshot snapshot) {String rid = snapshot.getValue(String.class);HashMap<String,Object> m = new HashMap<String,Object>();m.put("userid",rid);requestRef.child(mUser.getUid()).updateChildren(m);}@Override public void onCancelled(@NonNull DatabaseError error) {}});
                        Toast.makeText(driverlist_details.this, "Ride Request Sent!", Toast.LENGTH_SHORT).show();
                        declineReq.setVisibility(View.GONE);
                        CurrentState = "I_sent_pending";
//                        HashMap h = new HashMap();
//                        h.put("CurrentState","I_sent_pending");
//                        requestRef.child(mUser.getUid()).updateChildren(h);
                        sendReq.setText("Cancel Ride Request");
                    }
                    else{
                        Toast.makeText(driverlist_details.this, ""+task.getException().toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        if(CurrentState.equals("I_sent_pending")||CurrentState.equals("I_sent_decline")){//i sent or he decline
            requestRef.child(mUser.getUid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(driverlist_details.this, "Ride Request Canceled!", Toast.LENGTH_SHORT).show();
                        CurrentState = "nothing_happen";
//                        HashMap h = new HashMap();
//                        h.put("CurrentState","nothing_happen");
//                        requestRef.child(mUser.getUid()).updateChildren(h);
                        sendReq.setText("Send Friend Request");
                        declineReq.setVisibility(View.GONE);
                    }
                    else {
                        Toast.makeText(driverlist_details.this, ""+task.getException().toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        friendRef.child(mUser.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    if(snapshot.child("status").getValue().toString().equals("accepted"))
                    {

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
//        if(CurrentState.equals("he_sent_pending"))
//        {
//            requestRef.child(mUser.getUid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    if(task.isSuccessful()){
//                        HashMap hashMap = new HashMap();
//                        hashMap.put("status","accepted");
//                        hashMap.put("name",name);
//                        friendRef.child(mUser.getUid()).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
//                            @Override
//                            public void onComplete(@NonNull Task task) {
//                                if(task.isSuccessful()){
//                                    friendRef.child(mUser.getUid()).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
//                                        @Override
//                                        public void onComplete(@NonNull Task task) {
//                                            Toast.makeText(List_Details_Activity.this, "Friend Added!", Toast.LENGTH_SHORT).show();
//                                            CurrentState = "accepted";
////                                            HashMap h = new HashMap();
////                                            h.put("CurrentState","accepted");
////                                            requestRef.child(mUser.getUid()).updateChildren(h);
//                                            sendReq.setText("Send Hi!");
//                                            declineReq.setText("Unfriend");
//                                            declineReq.setVisibility(View.VISIBLE);
//                                        }
//                                    });
//                                }
//                            }
//                        });
//                    }
//                }
//            });
//        }
    }
//    if(CurrentState.equals("accepted")){
//        //
//    }

//    @Override
//    public void onBackPressed(){
//        if(pressed + 2000> System.currentTimeMillis()){
//            super.onBackPressed();
//            Intent i = new Intent(driverlist_details.this, driverlist_RiderPage.class);
//            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//            startActivity(i);
//            finish();
//        }
//        else {
//            Toast.makeText(driverlist_details.this, "Press Back again to go Back!", Toast.LENGTH_SHORT).show();
//        }
//        pressed = System.currentTimeMillis();
//    }

}
