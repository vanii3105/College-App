package com.example.RideMate;
//
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
//
//import com.github.mikephil.charting.charts.BarChart;
//import com.github.mikephil.charting.charts.LineChart;
//import com.github.mikephil.charting.data.BarData;
//import com.github.mikephil.charting.data.BarDataSet;
//import com.github.mikephil.charting.data.BarEntry;
//import com.github.mikephil.charting.data.Entry;
//import com.github.mikephil.charting.data.LineData;
//import com.github.mikephil.charting.data.LineDataSet;
//import com.github.mikephil.charting.utils.ColorTemplate;
//
//import java.util.ArrayList;
//
public class rider_graph_page extends AppCompatActivity
{
//    LineChart lineChart;
//    LineData lineData;
//    LineDataSet lineDataSet;
//    ArrayList lineEntries;
//    ArrayList barArraylist;
//    ArrayList lineArraylist;
//    @Override
//    protected void onCreate(Bundle savedInstanceState)
//    {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        getData();
//        BarChart barChart = findViewById(R.id.barchart);
//        LineChart lineChart=findViewById(R.id.linechart);
//        lineDataSet = new LineDataSet(lineEntries, "");
//        lineData = new LineData(lineDataSet);
//        lineChart.setData(lineData);
//        lineDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
//        lineDataSet.setValueTextColor(Color.BLACK);
//        lineDataSet.setValueTextSize(18f);
//
//        BarDataSet barDataSet = new BarDataSet(barArraylist,"");
//        BarData barData = new BarData(barDataSet);
//        barChart.setData(barData);
//        //color bar data set
//        barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
//        //text color
//        barDataSet.setValueTextColor(Color.BLACK);
//        //settting text size
//        barDataSet.setValueTextSize(16f);
//        barChart.getDescription().setEnabled(true);
//    }
//
//    private void getData()
//    {
//        barArraylist = new ArrayList();
//        barArraylist.add(new BarEntry(2f,10));
//        barArraylist.add(new BarEntry(3f,20));
//        barArraylist.add(new BarEntry(4f,30));
//        barArraylist.add(new BarEntry(5f,40));
//        barArraylist.add(new BarEntry(6f,50));
//
//        lineEntries = new ArrayList<>();
//        lineEntries.add(new Entry(2f, 0));
//        lineEntries.add(new Entry(4f, 1));
//        lineEntries.add(new Entry(6f, 1));
//        lineEntries.add(new Entry(8f, 3));
//        lineEntries.add(new Entry(7f, 4));
//        lineEntries.add(new Entry(3f, 3));
//
//    }
//
//
//
//
//
}