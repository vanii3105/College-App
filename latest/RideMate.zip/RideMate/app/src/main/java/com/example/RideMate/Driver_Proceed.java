package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Driver_Proceed extends AppCompatActivity {

    RecyclerView recview;
    Button proceed;
    dacceptedadapter adapter;
    DatabaseReference acceptedRef,ridestartedRef,historyRef,riderRef,driverRef,rideendRef;
    static int n = 1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_proceed);
        proceed = findViewById(R.id.proceed);
        recview = findViewById(R.id.recyclerView);

        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();

        acceptedRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("accepted");
        ridestartedRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("ridestarted");
        historyRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("history");
        riderRef = FirebaseDatabase.getInstance().getReference().child("riders");
        driverRef = FirebaseDatabase.getInstance().getReference().child("drivers");
        rideendRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("rideend");

        recview.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<dModel> options =
                new FirebaseRecyclerOptions.Builder<dModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("rideend"), dModel.class).build();
        adapter = new dacceptedadapter(options, getApplicationContext());
        recview.setAdapter(adapter);

        Toast.makeText(Driver_Proceed.this,"aaaa",Toast.LENGTH_SHORT).show();

        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(Driver_Proceed.this,"rrrr",Toast.LENGTH_SHORT).show();

                saveinHistory(currentuser);
                Toast.makeText(Driver_Proceed.this,"zzzz",Toast.LENGTH_SHORT).show();

//                ridestartedRef.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        for(DataSnapshot s : snapshot.getChildren()){
//                            String userid = s.child("userid").getValue().toString();
//                            String name = s.child("name").getValue().toString();
//                            String location = s.child("location").getValue().toString();
//                            String status = s.child("status").getValue().toString();
//                            String role = s.child("role").getValue().toString();
//                            HashMap<String, Object> m = new HashMap<String, Object>();
//                            m.put("name", name);
//                            m.put("location", location);
//                            m.put("userid", userid);
//                            m.put("status", "rideend");
//                            m.put("role",role);
//                            historyRef.child(userid).updateChildren(m);
////                            historyRef.child(currentDateandTime).child(userid).updateChildren(m);
//                            riderRef.child(userid).child("ridestarted").addValueEventListener(new ValueEventListener() {
//                                @Override
//                                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                    for(DataSnapshot s : snapshot.getChildren()){
//                                        String ruserid = s.child("userid").getValue().toString();
//                                        String rname = s.child("name").getValue().toString();
//                                        String rlocation = s.child("location").getValue().toString();
//                                        String rstatus = s.child("status").getValue().toString();
//                                        String rrole = s.child("role").getValue().toString();
//                                        HashMap<String, Object> m = new HashMap<String, Object>();
//                                        m.put("name", rname);
//                                        m.put("location", rlocation);
//                                        m.put("userid", ruserid);
//                                        m.put("status", "rideend");
//                                        m.put("role",rrole);
////                                        riderRef.child(userid).child("history").child(currentDateandTime).child(ruserid).updateChildren(m);
//                                        riderRef.child(userid).child("history").child(ruserid).updateChildren(m);
//                                    }
//                                    riderRef.child(userid).child("ridestarted").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
//                                        @Override
//                                        public void onComplete(@NonNull Task<Void> task) {
//
//                                        }
//                                    });
//                                }
//                                @Override
//                                public void onCancelled(@NonNull DatabaseError error) {
//
//                                }
//                            });
//                        }
//                        ridestartedRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
//                            @Override
//                            public void onComplete(@NonNull Task<Void> task) {
//
//                            }
//                        });
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });

                startActivity(new Intent(Driver_Proceed.this, DriverHomePage.class));
            }
        });
    }

    private void saveinHistory(String currentuser) {
        String count = Integer.toString(n);
        Toast.makeText(Driver_Proceed.this,"bbbb",Toast.LENGTH_SHORT).show();



        historyRef.child(count).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    n=n+1;
                    Toast.makeText(Driver_Proceed.this,"cccc",Toast.LENGTH_SHORT).show();
                    saveinHistory(currentuser);
                }
                else{
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
                    String currentDate = sdf.format(new Date());
                    SimpleDateFormat ldf = new SimpleDateFormat("HH:mm:ss");
                    String currentTime = ldf.format(new Date());

                    Toast.makeText(Driver_Proceed.this,"dddd",Toast.LENGTH_SHORT).show();


                    rideendRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            for(DataSnapshot s : snapshot.getChildren()){
                                Toast.makeText(Driver_Proceed.this,"eeee",Toast.LENGTH_SHORT).show();
                                String userid = s.child("userid").getValue().toString();
                                String name = s.child("name").getValue().toString();
                                String location = s.child("location").getValue().toString();
                                String status = s.child("status").getValue().toString();
                                String role = s.child("role").getValue().toString();
                                String purl = s.child("purl").getValue(String.class);

                                HashMap<String, Object> m = new HashMap<String, Object>();
                                m.put("name", name);
                                m.put("location", location);
                                m.put("userid", userid);
                                m.put("status", "inhistory");
                                m.put("role",role);
                                m.put("date",currentDate);
                                m.put("time",currentTime);
                                m.put("count",count);
                                m.put("purl",purl);
                                historyRef.child(count).child(userid).updateChildren(m);

                                HashMap<String, Object> h = new HashMap<String, Object>();
                                h.put("location", location);
                                h.put("date",currentDate);
                                h.put("time",currentTime);
                                h.put("count",count);
                                historyRef.child(count).updateChildren(h);



                                riderRef.child(userid).child("rideend").addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                                        for(DataSnapshot s : snapshot.getChildren()){
                                            String ruserid = s.child("userid").getValue().toString();
                                            String rname = s.child("name").getValue().toString();
                                            String rlocation = s.child("location").getValue().toString();
                                            String rstatus = s.child("status").getValue().toString();
                                            String rrole = s.child("role").getValue().toString();
                                            String rpurl = s.child("purl").getValue(String.class);

                                            HashMap<String, Object> m = new HashMap<String, Object>();
                                            m.put("name", rname);
                                            m.put("location", rlocation);
                                            m.put("userid", ruserid);
                                            m.put("status", "inhistory");
                                            m.put("role",rrole);
                                            m.put("date",currentDate);
                                            m.put("time",currentTime);
                                            m.put("count",count);
                                            m.put("rpurl",rpurl);
                                            riderRef.child(userid).child("history").child(count).child(ruserid).updateChildren(m);

                                            HashMap<String, Object> h = new HashMap<String, Object>();
                                            h.put("location", rlocation);
                                            h.put("date",currentDate);
                                            h.put("time",currentTime);
                                            h.put("count",count);
                                            riderRef.child(userid).child("history").child(count).updateChildren(h);

//                                            HashMap<String, Object> hm = new HashMap<String, Object>();
//                                            h.put("demostat", "ridefinish");
//                                            riderRef.child(userid).updateChildren(hm);
                                        }
                                        riderRef.child(userid).child("rideend").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                            }
                                        });
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            }
                            rideendRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                }
                            });
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }
    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}