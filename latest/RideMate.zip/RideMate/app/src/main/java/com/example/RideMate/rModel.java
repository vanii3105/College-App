package com.example.RideMate;

public class rModel {
    String name,source,destination,price,userid,purl,company;
    rModel() {

    }

    public rModel(String name, String source, String destination, String price, String userid, String purl, String company) {
        this.name = name;
        this.source = source;
        this.destination = destination;
        this.price = price;
        this.userid = userid;
        this.purl = purl;
        this.company = company;

    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }


    public String getPurl() {
        return purl;
    }

    public void setPurl(String purl) {
        this.purl = purl;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}
