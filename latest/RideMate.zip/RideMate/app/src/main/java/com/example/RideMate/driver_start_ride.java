package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class driver_start_ride extends AppCompatActivity {

    Button startride;
    ImageView chat;
    dacceptedadapter adapter;
    RecyclerView recview;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_start_ride);
        startride = findViewById(R.id.sride1);
        //chat = findViewById(R.id.chat);
        recview = findViewById(R.id.recviewaccepted);

        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss");
        String currentDateandTime = sdf.format(new Date());
        Toast.makeText(driver_start_ride.this, currentDateandTime, Toast.LENGTH_SHORT).show();

        recview.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<dModel> options =
                new FirebaseRecyclerOptions.Builder<dModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("accepted"), dModel.class).build();
        adapter = new dacceptedadapter(options, getApplicationContext());
        recview.setAdapter(adapter);

//        chat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(driver_start_ride.this, Driver_Chat_Activity.class));
//            }
//        });


        startride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(driver_start_ride.this, Driver_EndRide.class));

            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}