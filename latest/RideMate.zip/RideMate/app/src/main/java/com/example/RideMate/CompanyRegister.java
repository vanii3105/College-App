package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class CompanyRegister extends AppCompatActivity {
    FirebaseAuth auth;
    ImageView c_back_button;
    Button cnextBtn;
    TextInputEditText cemail, cpwd, ccpwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_register);
        auth=FirebaseAuth.getInstance();
        c_back_button = findViewById(R.id.c_back_button);
        cnextBtn = findViewById(R.id.cnextBtn);
        cemail = findViewById(R.id.cemail);
        cpwd = findViewById(R.id.cpwd);
        ccpwd = findViewById(R.id.ccpwd);
        c_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CompanyRegister.this, CompanyLoginActivity.class));
            }
        });
        cnextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Email = cemail.getText().toString();
                String Password = cpwd.getText().toString();
                if(TextUtils.isEmpty(Email) || TextUtils.isEmpty(Password))
                {
                    Toast.makeText(CompanyRegister.this , "Enter Values!!" , Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(CompanyRegister.this,"HELLLLLL",Toast.LENGTH_SHORT).show();
                    regist(Email,Password);
                }

            }

            private void regist(String Email, String Password) {
                auth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(CompanyRegister.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(CompanyRegister.this , "Registered Successfully!!" , Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(CompanyRegister.this,CompanyRegisterTwo.class);
//                    intent.putExtra(Email.toString(),Email);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(CompanyRegister.this , "Registration Failed!!" , Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

    }
}
