package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
//import com.google.firebase.messaging.FirebaseMessaging;
//import com.vanis.ridemate.SendNotificationPack.APIService;
//import com.vanis.ridemate.SendNotificationPack.Client;
//import com.vanis.ridemate.SendNotificationPack.Data;
//import com.vanis.ridemate.SendNotificationPack.MyResponse;
//import com.vanis.ridemate.SendNotificationPack.NotificationSender;
//import com.vanis.ridemate.SendNotificationPack.Token;

import java.util.HashMap;


public class riderRequest_Details extends AppCompatActivity {

    DatabaseReference requestRef,acceptedRef,ridacceptedRef,riderRef;
    FirebaseAuth mAuth;
    FirebaseUser mUser;
    ImageView rimg;
    TextView name,location,destination,dest,source;
    Button acceptReq,declineReq,back;
//    private APIService apiService;

    public static String CurrentState="";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_request_details);
        mAuth = FirebaseAuth.getInstance();
        mUser=mAuth.getCurrentUser();
        rimg=findViewById(R.id.rimg);


        name = findViewById(R.id.dummyName);
        destination = findViewById(R.id.dummydestination);
        dest = findViewById(R.id.dummydest);
        source = findViewById(R.id.dummySource);
        //location = findViewById(R.id.dummyLocation);
        acceptReq = findViewById(R.id.acceptbtn);
        declineReq = findViewById(R.id.declinebtn);

        name.setText(getIntent().getStringExtra("name"));
        source.setText(getIntent().getStringExtra("source"));
        dest.setText(getIntent().getStringExtra("destination"));


        final String userID = getIntent().getStringExtra("userid");
        final String url = getIntent().getStringExtra("purl");
        final String status = getIntent().getStringExtra("status");
        Glide.with(riderRequest_Details.this).load(url).into(rimg);
        requestRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(mUser.getUid()).child("requests");
        acceptedRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(mUser.getUid()).child("accepted");
        ridacceptedRef = FirebaseDatabase.getInstance().getReference().child("riders").child(userID).child("accepted");
        riderRef = FirebaseDatabase.getInstance().getReference().child("riders");
        destination.setVisibility(View.GONE);
        requestRef.child(userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    if(snapshot.child("status").getValue().toString().equals("pending"))
                    {
                        CurrentState="he_sent_pending";
                        acceptReq.setText("Accept Ride Request");
                        declineReq.setText("Decline Ride");
                        declineReq.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        acceptReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckUserExistence(userID);


            }
        });
    }


    private void CheckUserExistence(String userID) {
        if (CurrentState.equals("he_sent_pending")){
            requestRef.child(userID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists()){
                        CurrentState="accepted";
                        HashMap hashMap = new HashMap();
                        hashMap.put("status","accepted");
                        Toast.makeText(riderRequest_Details.this,"aajn",Toast.LENGTH_SHORT).show();
                        requestRef.child(userID).updateChildren(hashMap);
                        Toast.makeText(riderRequest_Details.this,"bbjn",Toast.LENGTH_SHORT).show();
                        FirebaseDatabase.getInstance().getReference().child("drivers").child(mUser.getUid()).child("accepted").child(userID).updateChildren(hashMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {
                                Toast.makeText(riderRequest_Details.this,"ccjn",Toast.LENGTH_SHORT).show();
                                FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();

                                FirebaseDatabase.getInstance().getReference().child("users").child(userID).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        String rname = snapshot.child("name").getValue(String.class);
                                        String source = snapshot.child("source").getValue(String.class);
                                        String destination = snapshot.child("destination").getValue(String.class);
                                        String userid = snapshot.child("userid").getValue(String.class);
                                        String purl = snapshot.child("purl").getValue(String.class);
                                        HashMap<String,Object> m = new HashMap<String,Object>();
                                        m.put("name",rname);
                                        m.put("source",source);
                                        m.put("destination",destination);
                                        m.put("userid",userid);
                                        m.put("status","accepted");
                                        m.put("role","rider");
                                        m.put("purl",purl);
                                        Toast.makeText(riderRequest_Details.this,"ggfn",Toast.LENGTH_SHORT).show();
                                        acceptedRef.child(userID).updateChildren(m);
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

//                                requestRef.child(userID).addValueEventListener(new ValueEventListener() {
//                                    @Override
//                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                        String rname = snapshot.child("name").getValue(String.class);
//                                        String rsource = snapshot.child("source").getValue(String.class);
//                                        String rdestination = snapshot.child("destination").getValue(String.class);
//                                        String rid = snapshot.child("userid").getValue(String.class);
//                                        String rpurl = snapshot.child("purl").getValue(String.class);
//                                        HashMap<String,Object> m = new HashMap<String,Object>();
//                                        Toast.makeText(riderRequest_Details.this,"ffjn",Toast.LENGTH_SHORT).show();
//                                        m.put("name",rname);
//                                        m.put("source",rsource);
//                                        m.put("destination",rdestination);
//                                        m.put("userid",rid);
//                                        m.put("status","accepted");
//                                        m.put("role","rider");
//                                        m.put("purl",rpurl);
//                                        Toast.makeText(riderRequest_Details.this,"ggfn",Toast.LENGTH_SHORT).show();
//                                        acceptedRef.child(userID).updateChildren(m);
//                                    }
//
//                                    @Override
//                                    public void onCancelled(@NonNull DatabaseError error) {
//
//                                    }
//                                });


//                                firebaseDatabase.getReference().child("riders").child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
//                                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                        Toast.makeText(riderRequest_Details.this,"ddjn",Toast.LENGTH_SHORT).show();
//                                        String rname = snapshot.child("name").getValue(String.class);
//                                        String rsource = snapshot.child("source").getValue(String.class);
//                                        String rdestination = snapshot.child("destination").getValue(String.class);
//                                        String rid = snapshot.child("userid").getValue(String.class);
//                                        String rpurl = snapshot.child("purl").getValue(String.class);
//                                        Toast.makeText(riderRequest_Details.this,"eejn",Toast.LENGTH_SHORT).show();
//                                        HashMap<String,Object> m = new HashMap<String,Object>();
//                                        Toast.makeText(riderRequest_Details.this,"ffjn",Toast.LENGTH_SHORT).show();
//                                        m.put("name",rname);
//                                        m.put("source",rsource);
//                                        m.put("destination",rdestination);
//                                        m.put("userid",rid);
//                                        m.put("status","accepted");
//                                        m.put("role","rider");
//                                        m.put("purl",rpurl);
//                                        Toast.makeText(riderRequest_Details.this,"ggfn",Toast.LENGTH_SHORT).show();
//                                        acceptedRef.child(userID).updateChildren(m);
//                                    }
//                                    @Override public void onCancelled(@NonNull DatabaseError error) {
//
//                                    }
//                                });
                                requestRef.child(userID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Toast.makeText(riderRequest_Details.this,"hhfn",Toast.LENGTH_SHORT).show();
                                    }
                                });

                                acceptedRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        Toast.makeText(riderRequest_Details.this,"iifn",Toast.LENGTH_SHORT).show();
                                        for(DataSnapshot s : snapshot.getChildren()){
                                            Toast.makeText(riderRequest_Details.this,"jjfn",Toast.LENGTH_SHORT).show();
                                            String userid = s.child("userid").getValue().toString();
                                            String name = s.child("name").getValue().toString();
                                            String source = s.child("source").getValue().toString();
                                            String destination = s.child("destination").getValue().toString();
                                            String status = s.child("status").getValue().toString();
                                            String purl = snapshot.child("purl").getValue(String.class);
                                            if(userID.equals(userid)){
                                                Toast.makeText(riderRequest_Details.this,"kkfn",Toast.LENGTH_SHORT).show();
                                                firebaseDatabase.getReference().child("drivers").child(mUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        Toast.makeText(riderRequest_Details.this,"llfn",Toast.LENGTH_SHORT).show();
                                                        String rname = snapshot.child("name").getValue(String.class);
//                                                        String rlocation = snapshot.child("location").getValue(String.class);
                                                        String rsource = snapshot.child("source").getValue(String.class);
                                                        String rdestination = snapshot.child("destination").getValue(String.class);
                                                        String rid = snapshot.child("userid").getValue(String.class);
                                                        String rpurl = snapshot.child("purl").getValue(String.class);
                                                        HashMap<String, Object> m = new HashMap<String, Object>();
                                                        m.put("name", rname);
//                                                        m.put("location", rlocation);
                                                        m.put("source", rsource);
                                                        m.put("destination", rdestination);
                                                        m.put("userid", rid);
                                                        m.put("status", "accepted");
                                                        m.put("role","driver");
                                                        m.put("purl", rpurl);
                                                        ridacceptedRef.child(mUser.getUid()).updateChildren(m);
                                                    }
                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {

                                                    }});
                                            }
                                            else{
                                                Toast.makeText(riderRequest_Details.this,"mmfn",Toast.LENGTH_SHORT).show();
                                                HashMap<String,Object> m = new HashMap<String,Object>();
                                                m.put("name",name);
//                                                m.put("location",location);
                                                m.put("source",source);
                                                m.put("destination",destination);
                                                m.put("userid",userid);
                                                m.put("status",status);
                                                m.put("role","rider");
                                                m.put("purl", purl);
                                                ridacceptedRef.child(userid).updateChildren(m);
                                                Toast.makeText(riderRequest_Details.this, "1111", Toast.LENGTH_SHORT).show();
                                                firebaseDatabase.getReference().child("drivers").child(mUser.getUid()).child("accepted").child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        Toast.makeText(riderRequest_Details.this, "2222", Toast.LENGTH_SHORT).show();
                                                        String rname = snapshot.child("name").getValue(String.class);
//                                                        String rlocation = snapshot.child("location").getValue(String.class);
                                                        String rsource = snapshot.child("source").getValue(String.class);
                                                        String rdestination = snapshot.child("destination").getValue(String.class);
                                                        String rid = snapshot.child("userid").getValue(String.class);
                                                        String rstatus = snapshot.child("status").getValue(String.class);
                                                        String rpurl = snapshot.child("purl").getValue(String.class);
                                                        HashMap<String, Object> m = new HashMap<String, Object>();
                                                        Toast.makeText(riderRequest_Details.this, rname, Toast.LENGTH_SHORT).show();
                                                        m.put("name", rname);
//                                                        m.put("location", rlocation);
                                                        m.put("source", rsource);
                                                        m.put("destination", rdestination);
                                                        m.put("userid", rid);
                                                        m.put("status", rstatus);
                                                        m.put("role","rider");
                                                        m.put("purl",rpurl);
                                                        riderRef.child(userid).child("accepted").child(userID).updateChildren(m);
                                                    }
                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {

                                                    }
                                                });
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
//                            acceptReq.setText("Send sms");
//                            declineReq.setText("unfriend");
                                destination.setVisibility(View.VISIBLE);
                                acceptReq.setVisibility(View.GONE);
                                declineReq.setVisibility(View.GONE);
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

// abab



//        friendRef.child(userID).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(snapshot.exists()){
//                    Toast.makeText(RequestList_Details_Activity.this, "ooo", Toast.LENGTH_LONG).show();
//                    CurrentState="accepted";
////                    HashMap h = new HashMap();
////                    h.put("CurrentState","accepted");
////                    requestRef.child(userID).updateChildren(h);
//                    acceptReq.setText("Send sms");
//                    declineReq.setText("unfriend");
//                    declineReq.setVisibility(View.VISIBLE);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//        requestRef.child(userID).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                Toast.makeText(RequestList_Details_Activity.this, "uuu", Toast.LENGTH_LONG).show();
//                if(snapshot.exists()){
//                    Toast.makeText(RequestList_Details_Activity.this, "rrr", Toast.LENGTH_LONG).show();
//                    if(snapshot.child("status").getValue().toString().equals("pending"))
//                    {
//                        Toast.makeText(RequestList_Details_Activity.this, "eee", Toast.LENGTH_LONG).show();
//                        CurrentState="I_sent_pending";
////                        HashMap h = new HashMap();
////                        h.put("CurrentState","I_sent_pending");
////                        requestRef.child(userID).updateChildren(h);
//                        acceptReq.setText("Cancel Friend Request");
//                        declineReq.setVisibility(View.GONE);
//                    }
//                    if(snapshot.child("status").getValue().toString().equals("decline"))
//                    {
//                        Toast.makeText(RequestList_Details_Activity.this, "www", Toast.LENGTH_LONG).show();
//                        CurrentState="I_sent_decline";
////                        HashMap h = new HashMap();
////                        h.put("CurrentState","I_sent_decline");
////                        requestRef.child(userID).updateChildren(h);
//                        acceptReq.setText("Cancel Friend Request");
//                        declineReq.setVisibility(View.GONE);
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//
//
//        requestRef.child(userID).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                Toast.makeText(RequestList_Details_Activity.this, "yyy", Toast.LENGTH_LONG).show();
//                if(snapshot.exists()){
//                    Toast.makeText(RequestList_Details_Activity.this, "pppp", Toast.LENGTH_LONG).show();
//                    if(snapshot.child("status").getValue().toString().equals("pending"))
//                    {
//                        Toast.makeText(RequestList_Details_Activity.this, "tttt", Toast.LENGTH_LONG).show();
//                        CurrentState="he_sent_pending";
////                        HashMap h = new HashMap();
////                        h.put("CurrentState","he_sent_pending");
////                        requestRef.child(userID).updateChildren(h);
//                        acceptReq.setText("Accept Friend Request");
//                        Toast.makeText(RequestList_Details_Activity.this, "iiii", Toast.LENGTH_LONG).show();
//                        declineReq.setText("Decline Friend");
//                        declineReq.setVisibility(View.VISIBLE);
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//        if(requestRef.child(userID).child("CurrentState").equals(("nothing_happen"))){
//            Toast.makeText(RequestList_Details_Activity.this, "qqq", Toast.LENGTH_LONG).show();
////            CurrentState.equals("nothing_happen");
//            HashMap h = new HashMap();
//            h.put("CurrentState","nothing_happen");
//            requestRef.child(userID).updateChildren(h);
//            acceptReq.setText("Send Friend Request");
//            declineReq.setVisibility(View.GONE);
//        }
    }
}
