package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
//        if(mAuth.getCurrentUser()!=null)
//        {
//            Toast.makeText(SplashActivity.this, "Already Logged In",Toast.LENGTH_LONG).show();
//            if()
//            Intent intent = new Intent(SplashActivity.this, Home.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//            startActivity(intent);
//        }
        new Handler().postDelayed(new  Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashActivity.this,WalkThrough.class));
                finish();
            }
        },3000);
    }

}