package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class DriverHomePage extends AppCompatActivity {
    SupportMapFragment smf;
    FusedLocationProviderClient client;
ImageView ddate,dtime,dswapid,dsurveybtn;
TextView dsetdate,dtimetext;
EditText dsrcid,ddestid;
String stime,sdate;
Button dsetridebtn;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_home_page);
        ddate=findViewById(R.id.ddate);
        dtime=findViewById(R.id.dtime);
        dswapid=findViewById(R.id.dswapid);
        dsetdate=findViewById(R.id.dsetdate);
        dtimetext=findViewById(R.id.dtimetext);
        dsrcid=findViewById(R.id.dsrcid);
        ddestid=findViewById(R.id.ddestid);
        dsetridebtn=findViewById(R.id.dsetridebtn);
        dsurveybtn=findViewById(R.id.dsurveybtn);
        int year,month,day;
        Menu menu;
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        final Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month= calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        dsurveybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        dtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(DriverHomePage.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        Calendar calendar2 = Calendar.getInstance();
                        calendar2.set(0,0,0,hourOfDay,minute);
                        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");
                        dtimetext.setText(sdf.format(calendar2.getTime()));
                        stime=dtimetext.getText().toString();
                    }
                },12,0,false);
                timePickerDialog.show();
            }
        });
        ddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dialog= new DatePickerDialog(DriverHomePage.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        dsetdate.setText(date);
                        sdate=dsetdate.getText().toString();
                    }
                },year,month,day);
                dialog.show();
            }
        });
        smf = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
        client = LocationServices.getFusedLocationProviderClient(this);
        Dexter.withContext(getApplicationContext())
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        getmylocation();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                }).check();
        dsetridebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    HashMap<String,Object> m = new HashMap<String,Object>();
                    m.put("source",dsrcid.getText().toString());
                    m.put("destination",ddestid.getText().toString());
                    m.put("Time",stime);
                    m.put("Date",sdate);
//                    m.put("userid",currentuser.toString());
                    FirebaseDatabase.getInstance().getReference().child("users").child(currentuser).updateChildren(m);
                    FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).updateChildren(m);
                FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String cname1=snapshot.child("company").getValue(String.class);
                        Toast.makeText(getApplicationContext(),"Your Ride hase been set ", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(DriverHomePage.this, RiderRequest_Driverpage.class);
                        FirebaseDatabase.getInstance().getReference().child("companyusers").child(cname1).child("drivers").child(currentuser).updateChildren(m);
                        intent.putExtra("company", cname1);
                        startActivity(intent);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
    }
    public void getmylocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        @SuppressLint("MissingPermission") Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(final Location location) {
                smf.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(GoogleMap googleMap) {
                        LatLng latLng=new LatLng(location.getLatitude(),location.getLongitude());
                        MarkerOptions markerOptions=new MarkerOptions().position(latLng).title("You are here...!!");

                        googleMap.addMarker(markerOptions);
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,17));
                    }
                });
            }
        });
    }
}