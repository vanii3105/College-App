package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class WalkThrough extends AppCompatActivity {


    private OnboardingAdapter onboardingAdapter;
    private LinearLayout layoutOnboardingIndicators;
    private MaterialButton buttonOnboardAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Toast.makeText(WalkThrough.this,"Walkthrough", Toast.LENGTH_LONG).show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_walk_through);

        layoutOnboardingIndicators=findViewById(R.id.layoutOnboardingIndicators);
        buttonOnboardAction=findViewById(R.id.buttonOnboardAction);

        setupOnboardingItems();
        ViewPager2 onboardingViewPager=findViewById(R.id.onboardingViewPager);
        onboardingViewPager.setAdapter(onboardingAdapter);
        setupOnboardingIndicators();
        setCurrentOnboardingIndicators(0);

        if (isOpenAlready()) {
            Toast.makeText(WalkThrough.this,"OpenAlready", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(WalkThrough.this, WelcomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } else {

            Toast.makeText(WalkThrough.this,"Newly Open", Toast.LENGTH_LONG).show();
            SharedPreferences.Editor editor = getSharedPreferences("slide", MODE_PRIVATE).edit();
            editor.putBoolean("slide", true);
            editor.commit();
        }

        onboardingViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                setCurrentOnboardingIndicators(position);
            }
        });


        buttonOnboardAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(onboardingViewPager.getCurrentItem()+1<onboardingAdapter.getItemCount()) {
                    onboardingViewPager.setCurrentItem(onboardingViewPager.getCurrentItem()+1);
                }
                startActivity(new Intent(WalkThrough.this,WelcomeActivity.class));
                finish();
            }
        });
    }

    private boolean isOpenAlready() {
        SharedPreferences sharedPreferences=getSharedPreferences("slide",MODE_PRIVATE);
        boolean result=sharedPreferences.getBoolean("slide",false);
        return result;
    }

    private void setupOnboardingItems() {
        List<OnboardingItem> onboardingItems =new ArrayList<>();
        OnboardingItem itemSearch = new OnboardingItem();
        itemSearch.setTitle("Search Your Drive Mate");
        itemSearch.setDescription("You can look for drivers close by or in the chosen city.\n" + "We'll show you the drivers that match your search.");
        itemSearch.setImage(R.drawable.searchyourdrivemate);

        OnboardingItem itemNature = new OnboardingItem();
        itemNature.setTitle("Save Fuel");
        itemNature.setDescription("Improve fuel efficiency while saving the environment.");
        itemNature.setImage(R.drawable.savefuel);

        OnboardingItem itemPay = new OnboardingItem();
        itemPay.setTitle("Split the fare");
        itemPay.setDescription("Share the fare with your fellow Ridemates.");
        itemPay.setImage(R.drawable.splitpayment);

        OnboardingItem itemCoworker = new OnboardingItem();
        itemCoworker.setTitle("Ride with your Colleagues");
        itemCoworker.setDescription("Find your coworkers Take the wheel or ride along.");
        itemCoworker.setImage(R.drawable.drivewithcolleagues);

        onboardingItems.add(itemSearch);
        onboardingItems.add(itemNature);
        onboardingItems.add(itemPay);
        onboardingItems.add(itemCoworker);

        onboardingAdapter = new OnboardingAdapter(onboardingItems);
    }
    private void setupOnboardingIndicators() {
        ImageView[] indicators = new ImageView[onboardingAdapter.getItemCount()];
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(8,0,8,0);
        for(int i=0;i<indicators.length;i++) {
            indicators[i]=new ImageView(getApplicationContext());
            indicators[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.onboarding_indicator_inactive));
            indicators[i].setLayoutParams(layoutParams);
            layoutOnboardingIndicators.addView(indicators[i]);
        }
    }
    @SuppressLint("SetTextI18n")
    private void setCurrentOnboardingIndicators(int index) {
        int childCount = layoutOnboardingIndicators.getChildCount();
        for(int i=0;i<childCount;i++) {
            ImageView imageView=(ImageView) layoutOnboardingIndicators.getChildAt(i);
            if(i == index) {
                imageView.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.onboarding_indicator_active));

            }
            else {
                imageView.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.onboarding_indicator_inactive));

            }
        }
        if(index==onboardingAdapter.getItemCount()-1) {
            buttonOnboardAction.setText("Start");
        }
        else {
            buttonOnboardAction.setText("Skip");
        }

    }
}