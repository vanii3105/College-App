package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Driver_EndRide extends AppCompatActivity {

    Button endride;
    DatabaseReference acceptedRef,ridestartedRef,historyRef,riderRef,driverRef,rideendRef;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_end_ride);
        endride = findViewById(R.id.endride);

        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();

        acceptedRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("accepted");
        ridestartedRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("ridestarted");
        historyRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("history");
        rideendRef = FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("rideend");
        riderRef = FirebaseDatabase.getInstance().getReference().child("riders");
        driverRef = FirebaseDatabase.getInstance().getReference().child("drivers");

        acceptedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot s : snapshot.getChildren()){
                    String userid = s.child("userid").getValue().toString();
                    String name = s.child("name").getValue().toString();
                    String location = s.child("location").getValue().toString();
                    String status = s.child("status").getValue().toString();
                    String role = s.child("role").getValue().toString();
                    String purl = s.child("purl").getValue(String.class);
                    HashMap<String, Object> m = new HashMap<String, Object>();
                    m.put("name", name);
                    m.put("location", location);
                    m.put("userid", userid);
                    m.put("role", role);
                    m.put("status", "ridestarted");
                    m.put("purl",purl);
                    ridestartedRef.child(userid).updateChildren(m);
                    riderRef.child(userid).child("accepted").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for(DataSnapshot s : snapshot.getChildren()){
                                String ruserid = s.child("userid").getValue().toString();
                                String rname = s.child("name").getValue().toString();
                                String rlocation = s.child("location").getValue().toString();
                                String rstatus = s.child("status").getValue().toString();
                                String rrole = s.child("role").getValue().toString();
                                String rpurl = s.child("purl").getValue(String.class);
                                HashMap<String, Object> m = new HashMap<String, Object>();
                                m.put("name", rname);
                                m.put("location", rlocation);
                                m.put("userid", ruserid);
                                m.put("status", "ridestarted");
                                m.put("role",rrole);
                                m.put("rpurl",rpurl);
                                riderRef.child(userid).child("ridestarted").child(ruserid).updateChildren(m);
                            }
                            riderRef.child(userid).child("accepted").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                }
                            });
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
                acceptedRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                    }
                });
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        endride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ridestartedRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot s : snapshot.getChildren()){
                            String userid = s.child("userid").getValue().toString();
                            String name = s.child("name").getValue().toString();
                            String location = s.child("location").getValue().toString();
                            String status = s.child("status").getValue().toString();
                            String role = s.child("role").getValue().toString();
                            String purl = s.child("purl").getValue(String.class);
                            HashMap<String, Object> m = new HashMap<String, Object>();
                            m.put("name", name);
                            m.put("location", location);
                            m.put("userid", userid);
                            m.put("role", role);
                            m.put("status", "rideend");
                            m.put("purl",purl);
                            rideendRef.child(userid).updateChildren(m);
                            riderRef.child(userid).child("ridestarted").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    for(DataSnapshot s : snapshot.getChildren()){
                                        String ruserid = s.child("userid").getValue().toString();
                                        String rname = s.child("name").getValue().toString();
                                        String rlocation = s.child("location").getValue().toString();
                                        String rstatus = s.child("status").getValue().toString();
                                        String rrole = s.child("role").getValue().toString();
                                        String rpurl = s.child("purl").getValue(String.class);
                                        HashMap<String, Object> m = new HashMap<String, Object>();
                                        m.put("name", rname);
                                        m.put("location", rlocation);
                                        m.put("userid", ruserid);
                                        m.put("status", "rideend");
                                        m.put("role",rrole);
                                        m.put("rpurl",rpurl);
                                        riderRef.child(userid).child("rideend").child(ruserid).updateChildren(m);
                                    }
                                    riderRef.child(userid).child("ridestarted").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                        }
                                    });
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }
                        ridestartedRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                            }
                        });
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                startActivity(new Intent(Driver_EndRide.this, Driver_Proceed.class));
            }
        });
    }
}