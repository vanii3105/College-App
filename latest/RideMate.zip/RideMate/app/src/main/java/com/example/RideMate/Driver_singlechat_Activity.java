//package com.example.RideMate;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.ArrayAdapter;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.ListView;
//import android.widget.Toast;
//
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//import com.firebase.ui.database.FirebaseRecyclerOptions;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//
//
//public class Driver_SingleChat_Activity extends AppCompatActivity {
//
//    RecyclerView recview;
//    EditText messageEd;
//    ImageView send;
//
//    DatabaseReference chatRef;
//    FirebaseAuth mAuth;
//    FirebaseUser mUser;
//    static int n = 1;
//
//    dsinglechatadapter adapter;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_driver_single_chat);
//
////        list = findViewById(R.id.recview);
//        recview = findViewById(R.id.recview);
//        messageEd = findViewById(R.id.messageEd);
//        send = findViewById(R.id.send);
//
//        mAuth = FirebaseAuth.getInstance();
//        mUser=mAuth.getCurrentUser();
//
//        final String userID = getIntent().getStringExtra("userid");
//        final String status = getIntent().getStringExtra("status");
//
//
//        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
//        chatRef = FirebaseDatabase.getInstance().getReference().child("chats").child(currentuser).child(userID);
//
//        Toast.makeText(Driver_SingleChat_Activity.this, "aaaa", Toast.LENGTH_LONG).show();
////        ArrayList<String> a = new ArrayList<>();
////        ArrayAdapter adapter = new ArrayAdapter<String>(Driver_SingleChat_Activity.this , R.layout.messagerow , a);
////        list.setAdapter(adapter);
////        Toast.makeText(Driver_SingleChat_Activity.this, "bbbb", Toast.LENGTH_LONG).show();
//
////        FirebaseDatabase.getInstance().getReference().child("chats").child(currentuser).child(userID).addValueEventListener(new ValueEventListener() {  //here you will have to add .child("(((id)))").sigleblhblah   for single value show
////            @Override
////            public void onDataChange(@NonNull DataSnapshot snapshot) {
////                Toast.makeText(Driver_SingleChat_Activity.this, "dddd", Toast.LENGTH_LONG).show();
////                if(snapshot.exists())
////                {
////                    Toast.makeText(Driver_SingleChat_Activity.this, snapshot.toString(), Toast.LENGTH_LONG).show();
////                    a.clear();
////                    for(DataSnapshot snapshot1:snapshot.getChildren())
////                    {
////                        Toast.makeText(Driver_SingleChat_Activity.this, snapshot1.toString(), Toast.LENGTH_LONG).show();
//////                        dmsgModel i = snapshot1.getValue(dmsgModel.class);  // no need to write this if you want to show only oe data
//////                        Toast.makeText(Driver_SingleChat_Activity.this, i.toString(), Toast.LENGTH_LONG).show();
//////                        String t = i.getMessage();
//////                        Toast.makeText(Driver_SingleChat_Activity.this, t, Toast.LENGTH_LONG).show();
//////                        a.add(t);
////                    }
////                    adapter.notifyDataSetChanged();
////                }
////            }
////
////            @Override
////            public void onCancelled(@NonNull DatabaseError error) {
////
////            }
////        });
//
//        recview.setLayoutManager(new LinearLayoutManager(this));
//        FirebaseRecyclerOptions<dmsgModel> options =
//                new FirebaseRecyclerOptions.Builder<dmsgModel>()
//                        .setQuery(FirebaseDatabase.getInstance().getReference().child("chats").child(currentuser).child(userID),dmsgModel.class).build();
//        adapter = new dsinglechatadapter(options,getApplicationContext());
//        recview.setAdapter(adapter);
//
//
//        send.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(Driver_SingleChat_Activity.this, "yyyy", Toast.LENGTH_LONG).show();
//                saveMsg(currentuser);
//            }
//        });
//
//    }
//
//    private void saveMsg(String currentuser) {
//        Toast.makeText(Driver_SingleChat_Activity.this, "rrrr", Toast.LENGTH_LONG).show();
//        final String message = messageEd.getText().toString();
//        String count = Integer.toString(n);
//        chatRef.child(count).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(snapshot.exists()){
//                    n=n+1;
//                    saveMsg(currentuser);
//                }
//                else{
//                    if(message.length()>0){
//                        HashMap h = new HashMap();
//                        h.put("message",message);
//                        h.put("sender","driver");
//                        h.put("userid",currentuser);
//                        chatRef.child(count).updateChildren(h);
//                        messageEd.setText("");
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
//
//    @Override
//    protected void onStart() {
//        super.onStart();
//        adapter.startListening();
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        adapter.stopListening();
//    }
//}