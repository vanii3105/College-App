package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Companydrivers extends AppCompatActivity {
    RecyclerView drecview;
    dacceptedadapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_companydrivers);
        drecview=findViewById(R.id.drecview2);
        drecview.setLayoutManager(new LinearLayoutManager(this));
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        final String name = getIntent().getStringExtra("name");
        FirebaseRecyclerOptions<dModel> options =
                new FirebaseRecyclerOptions.Builder<dModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("companyusers").child(name).child("drivers"),dModel.class).build();
        adapter = new dacceptedadapter(options,getApplicationContext());
        drecview.setAdapter(adapter);
    }
    @Override
    protected void onStart(){
        super.onStart();
        adapter.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        adapter.stopListening();
    }
}