package com.example.RideMate;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class driveradapter extends FirebaseRecyclerAdapter<dModel, driveradapter.myviewholder> {

    Context context;
    public driveradapter(@NonNull FirebaseRecyclerOptions<dModel> options, Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull driveradapter.myviewholder holder, int position, @NonNull dModel model) {

        holder.name.setText(model.getName());
        holder.source.setText(model.getSource());
        holder.destination.setText(model.getDestination());
        holder.userid.setText(model.getUserid());
        holder.status.setText(model.getStatus());
        Glide.with(holder.purl.getContext()).load(model.getPurl()).into(holder.purl);

        holder.name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, riderRequest_Details.class);
                intent.putExtra("name", model.getName());
                intent.putExtra("source", model.getSource());
                intent.putExtra("destination", model.getDestination());
                intent.putExtra("userid", model.getUserid());
                intent.putExtra("status", model.getStatus());
                intent.putExtra("purl", model.getPurl());

                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @NonNull
    @Override
    public driveradapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{
        TextView name,source,destination,userid,status;
        ImageView purl;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.t1);
            source = itemView.findViewById(R.id.t2);
            destination = itemView.findViewById(R.id.t21);
            userid = itemView.findViewById(R.id.t3);
            status = itemView.findViewById(R.id.t4);
            purl = itemView.findViewById(R.id.i);
        }
    }
}
