package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class CompanyOTP extends AppCompatActivity {

    ImageView cotpbackbtn;
    Button ceditphoneemail;
    Button cverifycodebtn;
    TextView phoneextra;
    String otp,VerificationID;
    PinView enterotp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_otp);

        cotpbackbtn=findViewById(R.id.cotpbackbtn);
        ceditphoneemail=findViewById(R.id.ceditphoneemail);
        cverifycodebtn=findViewById(R.id.cverifycodebtn);
        phoneextra=findViewById(R.id.phoneextra);
        enterotp=findViewById(R.id.enterotp);
        phoneextra.setText(String.format(
                "+91-%s",getIntent().getStringExtra("mobile")
        ));
        //enterotp.setText(String.format(getIntent().getStringExtra("s")));
        VerificationID=getIntent().getStringExtra(
                "VerificationID"
        );
        otp=getIntent().getStringExtra("s");
        enterotp.setText(otp);
        cotpbackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CompanyOTP.this,CompanyVerificationActivity.class));
            }
        });

        ceditphoneemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CompanyOTP.this,CompanyVerificationActivity.class));

            }
        });

        cverifycodebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(VerificationID,otp);
                    signinbyCredentials(credential);
                    //startActivity(new Intent(CompanyOTP.this,CompanyRegister.class));
            }
        });
    }
    private void signinbyCredentials(PhoneAuthCredential credential)
    {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task)
                    {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(CompanyOTP.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(CompanyOTP.this, CompanyHomePage.class));
                        }

                    }
                });}
}