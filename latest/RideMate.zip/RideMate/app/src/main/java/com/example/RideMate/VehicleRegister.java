package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class VehicleRegister extends AppCompatActivity {
    String type,fuel;
    driveradapter adapter;
    ImageView v_back_button;
    TextInputEditText vname,vnumber,vcapacity;
    Button vRegBtn;
    String name1,location1,gender1,company1,contact1,uri;
    RadioGroup vehtype,ftype;
    RadioButton radioButton,twowheel,fourwheel,petrolbtn,gasbtn,evbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_register);
        vRegBtn=findViewById(R.id.vRegBtn);
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        vehtype=findViewById(R.id.vehtype);
        vname=findViewById(R.id.vname);
        vnumber=findViewById(R.id.vnumber);
        vcapacity=findViewById(R.id.vcapacity);
        twowheel=findViewById(R.id.twowheel);
        fourwheel=findViewById(R.id.fourwheel);
        petrolbtn=findViewById(R.id.petrolbtn);
        gasbtn=findViewById(R.id.gasbtn);
        evbtn=findViewById(R.id.evbtn);
        ftype=findViewById(R.id.ftype);
        v_back_button=findViewById(R.id.v_back_button);
        v_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        vehtype.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = group.findViewById(checkedId);
                type= (String) radioButton.getText();
            }
        });
        ftype.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group1, int checkedId1) {
                RadioButton radioButton1=group1.findViewById(checkedId1);
                fuel= (String) radioButton1.getText();
            }
        });

        vRegBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String,Object> m = new HashMap<String,Object>();
                m.put("VehicleName",vname.getText().toString());
                m.put("VehicleNumber",vnumber.getText().toString());
                m.put("VehicleCapacity",vcapacity.getText().toString());
                m.put("VehicleType",type);
                m.put("Fueltype",fuel);
                m.put("userid",currentuser.toString());

                FirebaseDatabase.getInstance().getReference().child("users").child(currentuser).child("vehicles").updateChildren(m);
                FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("vehicles").updateChildren(m);
                FirebaseDatabase.getInstance().getReference().child("vehicle").child(fuel).child(currentuser).child("vehicles").updateChildren(m);
                FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        name1=snapshot.child("name").getValue(String.class);
                        company1=snapshot.child("company").getValue(String.class);
                        location1=snapshot.child("location").getValue(String.class);
                        gender1=snapshot.child("gender").getValue(String.class);
                        contact1=snapshot.child("contact").getValue(String.class);
                        uri=snapshot.child("purl").getValue(String.class);
                        HashMap<String,Object> m1 = new HashMap<String,Object>();
                        m1.put("name",name1);
                        m1.put("location",location1);
                        m1.put("gender",gender1);
                        m1.put("company",company1);
                        m1.put("contact",contact1);
                        m1.put("role","driver");
                        m1.put("userid",currentuser.toString());
                        m1.put("purl",uri);
                        FirebaseDatabase.getInstance().getReference().child("vehicle").child(fuel).child(currentuser).updateChildren(m1);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                startActivity(new Intent(VehicleRegister.this,DriverHomePage.class));
            }
        });


    }
}