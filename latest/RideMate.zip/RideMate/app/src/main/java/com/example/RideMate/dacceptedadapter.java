package com.example.RideMate;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class dacceptedadapter extends FirebaseRecyclerAdapter<dModel, dacceptedadapter.myviewholder> {

    Context context;
    public dacceptedadapter(@NonNull FirebaseRecyclerOptions<dModel> options, Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull dacceptedadapter.myviewholder holder, int position, @NonNull dModel model) {

        holder.name.setText(model.getName());
//
//        holder.location.setText(model.getLocation());
        holder.userid.setText(model.getUserid());
        holder.status.setText(model.getStatus());
        Glide.with(holder.purl.getContext()).load(model.getPurl()).into(holder.purl);

    }

    @NonNull
    @Override
    public dacceptedadapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new dacceptedadapter.myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{
        TextView name,location,userid,status,source,destination;
        ImageView purl;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.t1);
            source = itemView.findViewById(R.id.t2);
            userid = itemView.findViewById(R.id.t3);
            status = itemView.findViewById(R.id.t4);
            purl = itemView.findViewById(R.id.i);
        }
    }
}
