package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class RiderHomePage extends AppCompatActivity {
    SupportMapFragment smf;
    FusedLocationProviderClient client;
    ImageView dashboardbtn,date,time,swapid,homedash,surveybtnhome;
    int year,month,day;
    EditText srcid,destid;
    TextView setdate,timetext;
    Button ridebookbtn;
    ImageView acc_dash;
    Menu menu;
    FloatingActionButton floatmenu;
    String stime,sdate;
    String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_home_page);
        surveybtnhome=findViewById(R.id.surveybtn);
        homedash=findViewById(R.id.homedash);
        acc_dash=findViewById(R.id.acc_dash);
        ridebookbtn=findViewById(R.id.ridebookbtn);
        srcid=findViewById(R.id.srcid);
        swapid=findViewById(R.id.swapid);
        destid=findViewById(R.id.destid);
        //floatmenu=findViewById(R.id.floatmenu);
        setdate = findViewById(R.id.setdate);
        date=findViewById(R.id.date);
        time=findViewById(R.id.time);
        timetext=findViewById(R.id.timetext);
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        final Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month= calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        timetext=findViewById(R.id.timetext);


        surveybtnhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(RiderHomePage.this,rider_gracph_page.class));
            }
        });
        acc_dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RiderHomePage.this,account.class));
            }
        });
        swapid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = srcid.getText().toString();
                String d = destid.getText().toString();
                destid.setText(s);
                srcid.setText(d);

            }
        });
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(RiderHomePage.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        Calendar calendar2 = Calendar.getInstance();
                        calendar2.set(0,0,0,hourOfDay,minute);
                        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");
                        timetext.setText(sdf.format(calendar2.getTime()));
                        stime=timetext.getText().toString();
                    }
                },12,0,false);
                timePickerDialog.show();
            }
        });
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dialog= new DatePickerDialog(RiderHomePage.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        setdate.setText(date);
                        sdate=setdate.getText().toString();
                    }
                },year,month,day);
                dialog.show();
            }
        });
//        floatmenu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(RiderHomePage.this,));
//            }
//        });
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
         smf = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
        client = LocationServices.getFusedLocationProviderClient(this);
        Dexter.withContext(getApplicationContext())
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        getmylocation();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                }).check();
        ridebookbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String,Object> m = new HashMap<String,Object>();
                m.put("source",srcid.getText().toString());
                m.put("destination",destid.getText().toString());
                m.put("Time",stime);
                m.put("Date",sdate);
//                m.put("userid",currentuser.toString());

                FirebaseDatabase.getInstance().getReference().child("users").child(currentuser).updateChildren(m);
                FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).updateChildren(m);

                FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String cname1=snapshot.child("company").getValue(String.class);
                        Intent intent = new Intent(RiderHomePage.this, driverlist_RiderPage.class);
                        FirebaseDatabase.getInstance().getReference().child("companyusers").child(cname1).child("riders").child(currentuser).updateChildren(m);
                        intent.putExtra("company", cname1);
                        startActivity(intent);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }

    public void getmylocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        @SuppressLint("MissingPermission") Task<Location> task = client.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(final Location location) {
                smf.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(GoogleMap googleMap) {
                        LatLng latLng=new LatLng(location.getLatitude(),location.getLongitude());
                        MarkerOptions markerOptions=new MarkerOptions().position(latLng).title("You are here...!!");

                        googleMap.addMarker(markerOptions);
                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,17));
                    }
                });
            }
        });
    }


}
