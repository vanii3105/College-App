package com.example.RideMate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class CompanyRegisterTwo extends AppCompatActivity {

  ImageView cd_back_button;
  Button cdregisterbtn;
TextInputEditText cdname,cdaddress,cdstate,cdcity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_register_two);
        cdname=findViewById(R.id.cdname);
        cdaddress=findViewById(R.id.cdaddress);
        cdstate=findViewById(R.id.cdstate);
        cdcity=findViewById(R.id.cdcity);
        cd_back_button=findViewById(R.id.cd_back_button);
        cdregisterbtn=findViewById(R.id.cdregisterbtn);
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        cd_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CompanyRegisterTwo.this,CompanyRegister.class));
            }
        });
        cdregisterbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HashMap<String,Object> m = new HashMap<String,Object>();
                m.put("name",cdname.getText().toString());
                m.put("address",cdaddress.getText().toString());
                m.put("state",cdstate.getText().toString());
                m.put("city",cdcity.getText().toString());
                m.put("role","Company");
                m.put("userid",currentuser.toString());
                FirebaseDatabase.getInstance().getReference().child("Company").child(currentuser).setValue(m);
                //FirebaseDatabase.getInstance().getReference().child("")
                HashMap<String,Object> m2 = new HashMap<String,Object>();
                m2.put("name",cdname.getText().toString());
                FirebaseDatabase.getInstance().getReference().child("companynames").child(currentuser).updateChildren(m2);
                //FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).setValue(m);
                startActivity(new Intent(CompanyRegisterTwo.this,CompanyHomePage.class));
            }
        });
    }
}