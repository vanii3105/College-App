package com.example.RideMate;

public class dModel {
    String status,source,destination,userid,name,purl;
    dModel() {

    }



    public dModel(String name, String source, String destination,String userid, String purl, String status) {
        this.status = status;
        this.source = source;
        this.destination = destination;
        this.userid = userid;
        this.name = name;
        this.purl = purl;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }


    public String getPurl() {
        return purl;
    }

    public void setPurl(String purl) {
        this.purl = purl;
    }

}