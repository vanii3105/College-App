package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class rider_current_ride extends AppCompatActivity {

    ImageView chat;
    dacceptedadapter adapter;
    RecyclerView recview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_current_ride);
        chat = findViewById(R.id.chat);
        recview = findViewById(R.id.recview);
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        recview.setLayoutManager(new LinearLayoutManager(this));
        FirebaseRecyclerOptions<dModel> options =
                new FirebaseRecyclerOptions.Builder<dModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).child("accepted"), dModel.class).build();
        adapter = new dacceptedadapter(options, getApplicationContext());
        recview.setAdapter(adapter);
        FirebaseDatabase.getInstance().getReference().child("riders").child(currentuser).child("ridestarted").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    startActivity(new Intent(rider_current_ride.this, Rider_RideStarted.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//        chat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(rider_current_ride.this, Rider_Chat_Activity.class));
//            }
//        });
    }



    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}