package com.example.RideMate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RiderRequest_Driverpage extends AppCompatActivity {
    RecyclerView recview;
    LinearLayout linearLayout;
    driveradapter adapter;
    ScrollView scroll;
    Button acceptedbtn1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_request_driverpage);
        recview = findViewById(R.id.recview2);
        linearLayout=findViewById(R.id.llayout);
        scroll=findViewById(R.id.scroll);
        String currentuser = FirebaseAuth.getInstance().getCurrentUser().getUid();
        acceptedbtn1=findViewById(R.id.acceptedbtn1);
        acceptedbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            startActivity(new Intent(RiderRequest_Driverpage.this,driver_start_ride.class));
            }
        });
        FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("requests").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(!snapshot.exists())
                {
                    linearLayout.setVisibility(View.VISIBLE);
                    scroll.setVisibility(View.GONE);
                    recview.setVisibility(View.GONE);
                }
                else
                {
                    linearLayout.setVisibility(View.GONE);
                    scroll.setVisibility(View.VISIBLE);
                    recview.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        recview.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<dModel> options =
                new FirebaseRecyclerOptions.Builder<dModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("drivers").child(currentuser).child("requests"),dModel.class).build();
        adapter = new driveradapter(options,getApplicationContext());
        recview.setAdapter(adapter);

    }
    @Override
    protected void onStart(){
        super.onStart();
        adapter.startListening();
    }
    @Override
    protected void onStop(){
        super.onStop();
        adapter.stopListening();
    }
}