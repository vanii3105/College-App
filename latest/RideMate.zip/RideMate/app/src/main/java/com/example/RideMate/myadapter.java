package com.example.RideMate;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class myadapter extends FirebaseRecyclerAdapter<rModel,myadapter.myviewholder> {

    Context context;
    public myadapter(@NonNull FirebaseRecyclerOptions<rModel> options, Context context) {
        super(options);
        this.context=context;
    }

    @Override
    protected void onBindViewHolder(@NonNull myadapter.myviewholder holder, int position, @NonNull rModel model) {

        holder.name.setText(model.getName());
        holder.source.setText(model.getSource());
        holder.destination.setText(model.getDestination());
        holder.price.setText(model.getSource());
        holder.userid.setText(model.getUserid());
       Glide.with(holder.purl.getContext()).load(model.getPurl()).into(holder.purl);
//        Toast.makeText(context, "aaaaa", Toast.LENGTH_SHORT).show();
        holder.name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(context, "bbbb", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context, driverlist_details.class);
                intent.putExtra("name", model.getName());
                intent.putExtra("source", model.getSource());
                intent.putExtra("destination", model.getDestination());
                intent.putExtra("price", model.getPrice());
                intent.putExtra("userid", model.getUserid());
               intent.putExtra("purl", model.getPurl());
//                Toast.makeText(context, "cccc", Toast.LENGTH_SHORT).show();

                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @NonNull
    @Override
    public myadapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rider_singlerow,parent,false);
        return new myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder{
        TextView name,userid,source,destination,price;
        ImageView purl;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.t1);
            source = itemView.findViewById(R.id.t2);
            destination = itemView.findViewById(R.id.t21);
            price = itemView.findViewById(R.id.t22);
            userid = itemView.findViewById(R.id.t3);
            purl = itemView.findViewById(R.id.i);
        }
    }
}
