//package com.example.RideMate;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.firebase.ui.database.FirebaseRecyclerAdapter;
//import com.firebase.ui.database.FirebaseRecyclerOptions;
//
//public class rsinglechatadapter extends FirebaseRecyclerAdapter<dmsgModel, rsinglechatadapter.myviewholder> {
//
//    Context context;
//    public rsinglechatadapter(@NonNull FirebaseRecyclerOptions<dmsgModel> options, Context context) {
//        super(options);
//        this.context=context;
//    }
//
//    @Override
//    protected void onBindViewHolder(@NonNull rsinglechatadapter.myviewholder holder, int position, @NonNull dmsgModel model) {
//
////        holder.name.setText(model.getName());
////        holder.location.setText(model.getLocation());
////        holder.userid.setText(model.getUserid());
////        holder.status.setText(model.getStatus());
////        Glide.with(holder.purl.getContext()).load(model.getPurl()).into(holder.purl);
//        holder.message.setText(model.getMessage());
//        holder.sender.setText(model.getSender());
//        if (model.getSender().equals("driver")){
//            holder.main.setBackgroundColor(context.getResources().getColor(R.color.orange));
//            holder.main.setPadding(0,0,10,0);
//            holder.message.setTextColor(context.getResources().getColor(R.color.Black));
//        }
//        else {
//            holder.main.setBackgroundColor(context.getResources().getColor(R.color.grey));
//            holder.main.setPadding(10,0,0,0);
//            holder.message.setTextColor(context.getResources().getColor(R.color.Black));
//        }
////        holder.name.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                Intent intent = new Intent(context, Driver_SingleChat_Activity.class);
//////                intent.putExtra("name", model.getName());
//////                intent.putExtra("location", model.getLocation());
//////                intent.putExtra("userid", model.getUserid());
//////                intent.putExtra("status", model.getStatus());
//////                intent.putExtra("purl", model.getPurl());
////                intent.putExtra("name", model.getName());
////
////                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////                context.startActivity(intent);
////            }
////        });
//    }
//
////    @Override
////    public int getItemCount(){
////        return messageModelList.size();
////    }
//
//    @NonNull
//    @Override
//    public rsinglechatadapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.messagerow,parent,false);
//        return new rsinglechatadapter.myviewholder(view);
//    }
//
//    class myviewholder extends RecyclerView.ViewHolder{
//        //        TextView name,location,userid,status;
////        ImageView purl;
//        TextView message,sender;
//        LinearLayout main;
//
//
//        public myviewholder(@NonNull View itemView) {
//            super(itemView);
//            message = itemView.findViewById(R.id.message);
////            msgId = itemView.findViewById(R.id.msgId);
//            sender = itemView.findViewById(R.id.sender);
//            main = itemView.findViewById(R.id.mainMessageLayout);
////            name = itemView.findViewById(R.id.t1);
////            location = itemView.findViewById(R.id.t2);
////            userid = itemView.findViewById(R.id.t3);
////            status = itemView.findViewById(R.id.t4);
////            purl = itemView.findViewById(R.id.i);
//        }
//    }
//}
